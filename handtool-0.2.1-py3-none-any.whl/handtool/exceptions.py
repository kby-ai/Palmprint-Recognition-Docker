from .constants import PalmFeatureErrorCode, ReversedPalmFeatureErrorCode


class PalmFeatureExceptionBase(Exception):
    """Base exception for palm_feature"""

    def __init__(self, errcode, errmsg):
        """
        :param errcode: Error code
        :param errmsg: Error message
        """
        self.errcode = errcode
        self.errmsg = errmsg

    def __str__(self):
        return "Error code: {code}, means: {code_name}. Error message: {msg}".format(
            code=self.errcode,
            code_name=ReversedPalmFeatureErrorCode[self.errcode],
            msg=self.errmsg,
        )

    def __repr__(self):
        return self.__str__()
