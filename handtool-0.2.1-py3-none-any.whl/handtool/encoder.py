from .adapter import PalmFeatureAdapter
from .config import EncoderConfig
from .code import PalmprintCode


class Encoder(object):
    """Encode palmprint image to `Palmprint code`."""

    def __init__(self, config: EncoderConfig, adapter: PalmFeatureAdapter):
        self._cfg = config
        self._adapter = adapter
        self._id = self._adapter.new_encoder(self._cfg)

    def encode_using_file(self, filepath):
        with open(filepath, "rb") as palmprint:
            return self.encode_using_bytes(palmprint.read())

    def encode_using_bytes(self, image_bytes):
        code_bytes = self._adapter.do_encode(self._id, image_bytes)
        return PalmprintCode(code_bytes, self._adapter)
    
    def detect_using_file(self, filepath):
        with open(filepath, "rb") as palmprint:
            return self.detect_using_bytes(palmprint.read())
        
    def detect_using_bytes(self, image_bytes):
        hand_type, x1, y1, x2, y2, detect_state = self._adapter.do_detect(self._id, image_bytes)
        return hand_type, x1, y1, x2, y2, detect_state
    
    def init(self):
        return self._adapter.init()
    
    def getMachineCode(self):
        return self._adapter.getMachineCode()
    
    def setActivation(self, license):
        return self._adapter.setActivation(license)
