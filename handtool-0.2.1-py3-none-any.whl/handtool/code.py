from .adapter import PalmFeatureAdapter


class PalmprintCode(object):
    """Store code, compare to another code."""

    def __init__(self, code_bytes, adapter: PalmFeatureAdapter):
        self._code = code_bytes
        self._adapter = adapter

    def compare_to(self, another):
        return self._adapter.calc_score(self._code, another._code)
