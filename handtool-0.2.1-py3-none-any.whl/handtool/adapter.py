import platform
import ctypes

from .exceptions import PalmFeatureExceptionBase
from .config import EncoderConfig


class PalmFeatureAdapter(object):
    """An adapter for c apis in palm_feature library."""

    # LIB_NAME = "libhand.{suffix}".format(
        # suffix="so" if platform.uname()[0] == "Linux" else "dylib"
    # )
    LIB_NAME = "/usr/local/lib/libhand.so"
    LIB_INSTALLATION_URL = ("https://github.com/jackiewangCV/Touchless-Palm-Recognition-Android")
    # CROP_LIB_NAME = "/home/dev/work/palm-research/palmprint-recognition/lib/libcrop.so"
    def __init__(self):
        try:
            self._lib = ctypes.cdll.LoadLibrary(self.LIB_NAME)
            # self._lib_crop = ctypes.cdll.LoadLibrary(self.CROP_LIB_NAME)
        except OSError:
            raise OSError(
                "Library [{:s}] not found.\nPlease see {:s}".format(
                    self.LIB_NAME, self.LIB_INSTALLATION_URL
                )
            )

        # init palm_feature lib apis.
        self._lib.new_encoder_with_config.argtypes = [
            ctypes.c_uint8,
            ctypes.c_uint8,
            ctypes.c_uint8,
            ctypes.c_uint8,
            ctypes.c_char_p,
        ]
        self._lib.new_encoder_with_config.restype = ctypes.c_int

        self._lib.get_size_of_code_buffer_required.argtypes = [ctypes.c_int]
        self._lib.get_size_of_code_buffer_required.restype = ctypes.c_ulong

        self._lib.encode_palmprint_using_bytes.argtypes = [
            ctypes.c_int,
            ctypes.c_char_p,
            ctypes.c_ulong,
            ctypes.c_char_p,
            ctypes.c_ulong,
            ctypes.c_char_p,
        ]
        self._lib.encode_palmprint_using_bytes.restype = None

        self._lib.calculate_codes_similarity.argtypes = [
            ctypes.c_char_p,
            ctypes.c_char_p,
            ctypes.c_char_p,
        ]
        self._lib.calculate_codes_similarity.restype = ctypes.c_double

        self._lib.get_landmarks_using_bytes.argtypes = [
            ctypes.c_int,
            ctypes.c_char_p,
            ctypes.c_ulong,
            ctypes.c_char_p,
            ctypes.c_ulong,
            ctypes.c_char_p,
            ctypes.POINTER(ctypes.c_int),
            ctypes.POINTER(ctypes.c_int),
            ctypes.POINTER(ctypes.c_int),
            ctypes.POINTER(ctypes.c_int),
            ctypes.POINTER(ctypes.c_int),
            ctypes.POINTER(ctypes.c_int),
        ]
        self._lib.get_landmarks_using_bytes.restype = None
        
        self._lib.initSDK.argtypes = None
        self._lib.initSDK.restype = ctypes.c_int

        self._lib.getMachineCode.argtypes = None
        self._lib.getMachineCode.restype = ctypes.c_char_p

        self._lib.setActivation.argtypes = [ctypes.c_char_p]
        self._lib.setActivation.restype = ctypes.c_int
    
    def init(self):
        return self._lib.initSDK()
    
    def getMachineCode(self):
        return self._lib.getMachineCode()
    
    def setActivation(self, license):
        return self._lib.setActivation(license)


    def new_encoder(self, config: EncoderConfig):
        """Create a new encoder and return it's id."""
        status = ctypes.create_string_buffer(128)
        encoder_id = self._lib.new_encoder_with_config(
            config.image_size,
            config.gabor_kernel_size,
            config.laplace_kernel_size,
            config.gabor_directions,
            status,
        )
        self._check_status(status)
        return encoder_id

    def do_encode(self, encoder_id, palmprint_bytes):
        """Encode palmprint image bytes to code bytes."""
        status = ctypes.create_string_buffer(128)
        code_bytes_size = self._lib.get_size_of_code_buffer_required(encoder_id)
        code_bytes = ctypes.create_string_buffer(code_bytes_size)
        self._lib.encode_palmprint_using_bytes(
            encoder_id,
            palmprint_bytes,
            len(palmprint_bytes),
            code_bytes,
            code_bytes_size,
            status,
        )

        self._check_status(status)
        return code_bytes
    
    def do_detect(self, encoder_id, image_bytes):
        """Encode palmprint image bytes to code bytes."""
        status = ctypes.create_string_buffer(128)
        code_bytes_size = self._lib.get_size_of_code_buffer_required(encoder_id)
        code_bytes = ctypes.create_string_buffer(code_bytes_size)
        hand_type = ctypes.c_int()
        x1 = ctypes.c_int()
        y1 = ctypes.c_int()
        x2 = ctypes.c_int()
        y2 = ctypes.c_int()
        detect_state = ctypes.c_int()
        self._lib.get_landmarks_using_bytes(
            encoder_id,
            image_bytes,
            len(image_bytes),
            code_bytes,
            code_bytes_size,
            status,
            ctypes.POINTER(ctypes.c_int)(hand_type),
            ctypes.POINTER(ctypes.c_int)(x1),
            ctypes.POINTER(ctypes.c_int)(y1),
            ctypes.POINTER(ctypes.c_int)(x2),
            ctypes.POINTER(ctypes.c_int)(y2),
            ctypes.POINTER(ctypes.c_int)(detect_state),
        )
        
        self._check_status(status)
        return hand_type.value, x1.value, y1.value, x2.value, y2.value, detect_state.value
        
    def calc_score(self, lhs_code_bytes, rhs_code_bytes):
        """Calculate two codes similarity score."""
        status = ctypes.create_string_buffer(128)
        score = self._lib.calculate_codes_similarity(
            lhs_code_bytes, rhs_code_bytes, status
        )
        self._check_status(status)
        return score

    @staticmethod
    def _check_status(status):
        code = status.raw[0]
        if code != 0:
            raise PalmFeatureExceptionBase(errcode=code, errmsg=status.raw[1:].decode())
