import enum


@enum.unique
class PalmFeatureErrorCode(enum.IntEnum):
    InvalidArgument = 1
    LackingCodeBuffer = 2
    CodeCfgNEWhenComparing = 3


ReversedPalmFeatureErrorCode = {f.value: f.name for f in PalmFeatureErrorCode}
